#include "linktable.h"

tDataNode *FindCmd(tLinkTable * pLinkTable, char *cmd);

int ShowAllCmd(tLinkTable * pLinkTable);


int Help();

int Rm();

