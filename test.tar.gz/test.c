//#include "linktable.h"
#include "menu.h"
#define debug printf

/*node for test*/
typedef struct Node
{
	tLinkTableNode * pNext;
	int data;
}tNode;

tNode * Search(tLinkTable *pLinkTable);
int SearchConditon(tLinkTableNode * pLinkTableNode);

int main()
{
	int i;
	tLinkTable *pLinkTable = CreateLinkTable();
	if(pLinkTable == NULL)
    {
        debug("create linktable fail\n");
    }
	debug("create link table success\n");

	for(i = 0; i < 10; i++)
    {
        tNode* pNode = (tNode*)malloc(sizeof(tNode));
        pNode->data = i;
        debug("AddLinkTableNode %d\n",i);
        int j = AddLinkTableNode(pLinkTable,(tLinkTableNode *)pNode);
    	if (j = FAILURE)
		{
			printf("add link table node success\n");
		}
	}
	/*search by callback function return int 1*/
	debug("SearchLinkTableNode by callback function\n");
	tNode *pTempNode;
	pTempNode = (tNode*)SearchLinkTableNode(pLinkTable,SearchConditon);
	printf("%d\n",pTempNode->data);
	debug("search by callback success\n");
	
	/* search one by one return int 2*/
    debug("search one by one \n");
	pTempNode = Search(pLinkTable);
    printf("%d\n",pTempNode->data);
 	debug("search one by one success\n");

}



tNode * Search(tLinkTable *pLinkTable)
{
    debug("Search GetLinkTableHead\n");
    tNode * pNode = (tNode*)GetLinkTableHead(pLinkTable);
    while(pNode != NULL)
    {
        if(pNode->data == 2)
        {
            return  pNode;  
        }
        debug("GetNextLinkTableNode\n");
        pNode = (tNode*)GetNextLinkTableNode(pLinkTable,(tLinkTableNode *)pNode);
    }
    return NULL;
}

int SearchConditon(tLinkTableNode * pLinkTableNode)
{
    tNode * pNode = (tNode *)pLinkTableNode;
    if(pNode->data == 1)
    {
        return  SUCCESS;  
    }
    return FAILURE;	       
}
