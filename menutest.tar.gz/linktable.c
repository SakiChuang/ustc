/********************************************************************/
/* Copyright (C) SSE-USTC, 2012-2013                                */
/*                                                                  */
/*  FILE NAME             :  linktable.h                            */
/*  PRINCIPAL AUTHOR      :  Zhuangzhewei                           */
/*  SUBSYSTEM NAME        :  LinkTable                              */
/*  MODULE NAME           :  LinkTable                              */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/23                             */
/*  DESCRIPTION           :  interface of Link Table                */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by Zhuangzhewei,2014/09/23
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "linktable.h"

/*
 * LinkTable Type
 */
typedef struct LinkTable
{
	tLinkTableNode *pHead;
	tLinkTableNode *pTail;
	int			SumOfNode;
	pthread_mutex_t mutex;
	
}tLinkTable;

/*
 * DataNode Node Type
 */


/*
 * Create a LinkTable
 */
tLinkTable *CreateLinkTable()
{
	tLinkTable *pLinkTable = (tLinkTable *)malloc(sizeof(tLinkTable));
	if(pLinkTable == NULL)
	{
		return NULL;
    }
	pLinkTable->pHead = NULL;
	pLinkTable->pTail = NULL;
	pLinkTable->SumOfNode = 0;
	pthread_mutex_init(&(pLinkTable->mutex), NULL);
	return pLinkTable;
}






/*
 * Delete a LinkTable
 */
int DeleteLinkTable(tLinkTable *pLinkTable)
{
	if(pLinkTable == NULL)
	{
		return FAILURE;
    }
	while(pLinkTable->pHead != NULL)
	{
		tLinkTableNode * p = pLinkTable->pHead;
		pthread_mutex_lock(&(pLinkTable->mutex));
		pLinkTable->pHead = pLinkTable->pHead->pNext;
		pLinkTable->SumOfNode -= 1 ;
		pthread_mutex_unlock(&(pLinkTable->mutex));
		free(p);
	}
	pLinkTable->pHead = NULL;
	pLinkTable->pTail = NULL;
	pLinkTable->SumOfNode = 0;
	pthread_mutex_destroy(&(pLinkTable->mutex));
	free(pLinkTable);
	return SUCCESS;		
}

/*
 * Add a LinkTableNode to LinkTable
 */
int AddLinkTableNode(tLinkTable *pLinkTable,tLinkTableNode * pNode)
{
	if(pLinkTable == NULL || pNode == NULL)
	{
		return FAILURE;
    }
	pNode->pNext = NULL;
	pthread_mutex_lock(&(pLinkTable->mutex));
	if(pLinkTable->pHead == NULL)
	{
		pLinkTable->pHead = pNode;
	}
	if(pLinkTable->pTail == NULL)
	{
		pLinkTable->pTail = pNode;
	}
	else
	{
		pLinkTable->pTail->pNext = pNode;
		pLinkTable->pTail = pNode;
	}
	pLinkTable->SumOfNode += 1 ;
	pthread_mutex_unlock(&(pLinkTable->mutex));
	return SUCCESS;		
}


/*
 * Delete a LinkTableNode from LinkTable
 */
int DelLinkTableNode(tLinkTable *pLinkTable,tLinkTableNode * pNode)
{
	if(pLinkTable == NULL || pNode == NULL)
	{
		return FAILURE;
    }
    pthread_mutex_lock(&(pLinkTable->mutex));
    if(pLinkTable->pHead == pNode)
    {
        pLinkTable->pHead = pLinkTable->pHead->pNext;
    	pLinkTable->SumOfNode -= 1 ;
    	if(pLinkTable->SumOfNode == 0)
    	{
    		pLinkTable->pTail = NULL;	
    	}
    	pthread_mutex_unlock(&(pLinkTable->mutex));
    	return SUCCESS;
    }
    tLinkTableNode * pTempNode = pLinkTable->pHead;
	while(pTempNode != NULL)
    {    
		if(pTempNode->pNext == pNode)
		{
		    pTempNode->pNext = pTempNode->pNext->pNext;
    		pLinkTable->SumOfNode -= 1 ;
    		if(pLinkTable->SumOfNode == 0)
    		{
    			pLinkTable->pTail = NULL;	
    		}
    		pthread_mutex_unlock(&(pLinkTable->mutex));
    		return SUCCESS;				    
		}
		pTempNode = pTempNode->pNext;
	}
	pthread_mutex_unlock(&(pLinkTable->mutex));
	return FAILURE;		
}


/*
 * Search a LinkTableNode from LinkTable
 * int Conditon(tLinkTableNode * pNode);
 */
tLinkTableNode * SearchLinkTableNode(tLinkTable *pLinkTable, int Conditon(tLinkTableNode * pNode))
{
    if(pLinkTable == NULL || Conditon == NULL)
	{
		return NULL;
    }
    tLinkTableNode * pNode = pLinkTable->pHead;
	while(pNode != pLinkTable->pTail)
    {    
		if(Conditon(pNode) == SUCCESS)
        {
    		return pNode;				    
		}
		pNode = pNode->pNext;
	}
	return NULL;
}






/*delete a node */ 
/*void DeleteNode()
{
	struct node *p,*q;
 	q=h;  
    p=h->next ;
    char DeleteCmd[CMD_MAX_LEN];
	scanf("%s",DeleteCmd);
  	//查找要删除结点的位置
	if(p!=NULL)
 	{
		while((p!=NULL)&&(p->data!=z))
  		{
   			q=p;
   			p=p->next;
  		}
  		//释放结点
  		if(p->data ==z)
  		{
   			q->next=p->next ;
   			free(p);
		}
    	printf("can not find this cmd");
 	}
 	return();
} 
*/


/*initial linkTable*/
/*void LinkInit(tLinkTable ** ppLinktable)
{
 	tDataNode *r;
 	tDataNode *p;
 	int i = 0;
 	int length = sizeof(head)/sizeof(head[0]);		//length of head[]
    r = (tDataNode *)malloc(sizeof(tDataNode));   //申请结点空间 
    r->next = NULL;
	for(i = 0;i<length;i++)
    {   	
    	p = (tDataNode*)malloc(sizeof(tDataNode));
    	*p = head[i];
    	r->next = p
    	r = r->next
	}
	r->next = NULL;
	return 0;
	*/
	
	/*
	*ppLinktable = CreateLinkTable();
    
	tDataNode* pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "help";
    pNode->desc = "Menu Table:";
    pNode->handler = Help;
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    
	
	pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "version";
    pNode->desc = "Menu Program V1.0";
    pNode->handler = NULL; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
    pNode = (tDataNode*)malloc(sizeof(tDataNode));
    pNode->cmd = "quit";
    pNode->desc = "Quit from Menu Program V1.0";
    pNode->handler = Quit; 
    AddLinkTableNode(*ppLinktable,(tLinkTableNode *)pNode);
 
    return 0; 
    
    
}

*/


/*make LinkTable */ 
/*tLinkTableNode * GetLinkTable (*tLinkTableNode pLinkTable)		
{
	pLinkTable = (tLinkTableNode*)malloc(sizeof(tLinkTableNode));        
	pLinkTable->= NULL;        
	pLinkTable->next = NULL;
}
*/
/*
 * Get LinkTableHead 
 */
tLinkTableNode *GetLinkTableHead(tLinkTable *pLinkTable)
{
	if(pLinkTable == NULL)
	{
		return NULL;
	}
	return pLinkTable->pHead;
} 
 
/*
 * get next LinkTableNode
 */
tLinkTableNode * GetNextLinkTableNode(tLinkTable *pLinkTable,tLinkTableNode * pNode)
{
	if(pLinkTable == NULL || pNode == NULL)
	{
		return NULL;
    }
    tLinkTableNode * pTempNode = pLinkTable->pHead;
	while(pTempNode != NULL)
    {    
		if(pTempNode == pNode)
        {
    		return pTempNode->pNext;				    
		}
		pTempNode = pTempNode->pNext;
	}
	return NULL;
}




