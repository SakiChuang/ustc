This is a menu program 
To build program
$ gcc menu.c linktable.c -o menutest
$ ./menutest   #run this program you can input help,version,rm command

