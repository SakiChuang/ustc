/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  zhuangzhewei                                                         */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/23                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by zhuangzhewei, 2014/09/23
 *
 */

// menu.cpp : 定义控制台应用程序的入口点。
//

#include <stdio.h>
#include <stdlib.h>
//#include "menu.h"
#include "linktable.h"

int Help();
int Rm();

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     10

/* menu program */

int ShowAllCmd(tLinkTable * head)
{
	tDataNode *pNode = (tDataNode *)GetLinkTableHead(head);
	while(pNode != NULL)
	{
		printf("%s -%s\n", pNode->cmd, pNode->desc);
		pNode = (tDataNode *)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
	}
	return SUCCESS;
}

tDataNode* FindCmd(tDataNode * head,char * cmd)		
{
    if(head == NULL||cmd == NULL)
    {
    	return NULL;
    }
    tDataNode *p = head;
    while(p != NULL)
    {
		if(strcmp(cmd,p->cmd)==0)
		{	
	 		return p;
		    break;	
		}
		p=p->pNext;
    }
    if(p == NULL)					
    {
		printf("This is a wrong cmd!\n ");
    }
    return NULL;
}


static tDataNode Data[]=
{
    {NULL,"help","this is help cmd!",Help},
    {NULL,"version","menu program v1.0",NULL},
    {NULL,"rm","this is rm cmd!",Rm}	
};


tLinkTable *pLinkTable = NULL;
tDataNode  *p = NULL;

int main()
{	 
	pLinkTable = CreateLinkTable();
	AddLinkTableNode(pLinkTable, (tLinkTableNode *)&Data[0]);
	AddLinkTableNode(pLinkTable, (tLinkTableNode *)&Data[1]);
	AddLinkTableNode(pLinkTable, (tLinkTableNode *)&Data[2]);
	while(1)
    {
        char GetCmd[CMD_MAX_LEN];
        printf("Input a cmd string >");
        scanf("%s",GetCmd);
        p = FindCmd(pLinkTable, GetCmd);
        if(p == NULL)
        {
            printf("This is a wrong cmd!\n");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc);
        if(p->handle != NULL)
        {
            p->handle();
        }
    }
    return 0;
}



/*show all cmd*/

/*void ShowCmdList(tDataNode * head)
{
    printf("Menu List:\n");
	    
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return 0;


}
*/
/*find cmd from linktable*/



/*int SearchConditon(tLinkTableNode * pLinkTableNode)
{
    tNode * pNode = (tNode *)pLinkTableNode;
    if(pNode->data == 6)
    {
        return  SUCCESS;  
    }
    return FAILURE;	       
}
*/ 

int Help()
{
    ShowAllCmd(Data);
    return 0;
}

int Rm()
{
    printf("Please confirm your delete command?\n");
    return 0;
}


