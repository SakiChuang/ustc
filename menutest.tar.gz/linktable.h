
/********************************************************************/
/* Copyright (C) SSE-USTC, 2012-2013                                */
/*                                                                  */
/*  FILE NAME             :  linktable.h                            */
/*  PRINCIPAL AUTHOR      :  Zhuangzhewei                           */
/*  SUBSYSTEM NAME        :  LinkTable                              */
/*  MODULE NAME           :  LinkTable                              */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2014/09/23                             */
/*  DESCRIPTION           :  interface of Link Table                */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by Zhuangzhewei,2014/09/23
 *
 */
 



#define SUCCESS 0
#define FAILURE (-1)

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     10

/*
 * LinkTable Node Type
 */
typedef struct LinkTableNode
{
	struct LinkTableNode * pNext;
}tLinkTableNode;

/*
 * LinkTable Type
 */

typedef struct LinkTable tLinkTable;

//typedef struct DataNode tDataNode;
typedef struct DataNode
{
    tLinkTableNode *pNext;
    char cmd[CMD_MAX_LEN];
    char desc[DESC_LEN];
    int  (*handle)();
}tDataNode;
  

/*
 * Create a LinkTable
 */
tLinkTable * CreateLinkTable();

/*
 * Delete a LinkTable
 */
int DeleteLinkTable(tLinkTable *pLinkTable);

/*
 * Add a LinkTableNode to LinkTable
 */
int AddLinkTableNode(tLinkTable *pLinkTable,tLinkTableNode * pNode);

/*
 * Delete a LinkTableNode from LinkTable
 */
int DelLinkTableNode(tLinkTable *pLinkTable,tLinkTableNode * pNode);

/*
 * Search a LinkTableNode from LinkTable
 */
tLinkTableNode * SearchLinkTableNode(tLinkTable *pLinkTable, int Conditon(tLinkTableNode * pNode));

/*
 * get LinkTableHead
 */
tLinkTableNode * GetLinkTableHead(tLinkTable *pLinkTable);

/*
 * get next LinkTableNode
 */
tLinkTableNode * GetNextLinkTableNode(tLinkTable *pLinkTable,tLinkTableNode * pNode);

